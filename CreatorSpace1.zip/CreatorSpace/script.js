// =========================================
// CreatorSpace - Complete JavaScript
// =========================================

document.addEventListener("DOMContentLoaded", () => {
  // -----------------------------------------
  // Current Year
  // -----------------------------------------
  const yearElement = document.querySelector("#year");

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  // -----------------------------------------
  // Mobile Navigation
  // -----------------------------------------
  const navContent = document.querySelector(".nav-content");
  const menuToggle = document.querySelector(".menu-toggle");
  const navLinks = document.querySelectorAll(".nav-links a");

  if (navContent && menuToggle) {
    menuToggle.addEventListener("click", () => {
      const isOpen = navContent.classList.toggle("menu-open");

      menuToggle.classList.toggle("active", isOpen);
      menuToggle.setAttribute("aria-expanded", String(isOpen));
    });

    navLinks.forEach((link) => {
      link.addEventListener("click", () => {
        navContent.classList.remove("menu-open");
        menuToggle.classList.remove("active");
        menuToggle.setAttribute("aria-expanded", "false");
      });
    });

    document.addEventListener("click", (event) => {
      if (!navContent.contains(event.target)) {
        navContent.classList.remove("menu-open");
        menuToggle.classList.remove("active");
        menuToggle.setAttribute("aria-expanded", "false");
      }
    });
  }

  // -----------------------------------------
  // Navbar Scroll Effect
  // -----------------------------------------
  const navbar = document.querySelector(".navbar");

  const updateNavbar = () => {
    if (!navbar) return;

    if (window.scrollY > 30) {
      navbar.classList.add("scrolled");
    } else {
      navbar.classList.remove("scrolled");
    }
  };

  window.addEventListener("scroll", updateNavbar, { passive: true });
  updateNavbar();

  // -----------------------------------------
  // Scroll Reveal
  // -----------------------------------------
  const revealElements = document.querySelectorAll(".reveal");

  if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver(
      (entries, observer) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("revealed");
            observer.unobserve(entry.target);
          }
        });
      },
      {
        threshold: 0.12,
      }
    );

    revealElements.forEach((element) => {
      revealObserver.observe(element);
    });
  } else {
    revealElements.forEach((element) => {
      element.classList.add("revealed");
    });
  }

  // -----------------------------------------
  // 3D Mouse Tilt Effect
  // -----------------------------------------
  const tiltCards = document.querySelectorAll("[data-tilt]");

  tiltCards.forEach((card) => {
    let isTouchDevice = false;

    card.addEventListener("touchstart", () => {
      isTouchDevice = true;
    }, { passive: true });

    card.addEventListener("mousemove", (event) => {
      if (isTouchDevice || window.innerWidth < 780) return;

      const rect = card.getBoundingClientRect();

      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;

      const centerX = rect.width / 2;
      const centerY = rect.height / 2;

      const rotateX = ((y - centerY) / centerY) * -5;
      const rotateY = ((x - centerX) / centerX) * 7;

      card.style.transform = `
        perspective(1200px)
        rotateX(${rotateX}deg)
        rotateY(${rotateY}deg)
        translateZ(0)
      `;
    });

    card.addEventListener("mouseleave", () => {
      card.style.transform = "perspective(1200px) rotateX(0deg) rotateY(0deg)";
    });
  });

  // -----------------------------------------
  // Smooth Internal Anchor Scroll
  // -----------------------------------------
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const targetId = link.getAttribute("href");

      if (!targetId || targetId === "#") {
        event.preventDefault();
        return;
      }

      const target = document.querySelector(targetId);

      if (target) {
        event.preventDefault();

        target.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });
      }
    });
  });

    // -----------------------------------------
  // Contact Form - Web3Forms
  // -----------------------------------------
  const contactForm = document.querySelector("#contactForm");
  const formMessage = document.querySelector("#formMessage");

  if (contactForm && formMessage) {
    contactForm.addEventListener("submit", async (event) => {
      event.preventDefault();

      const submitButton = contactForm.querySelector(
        'button[type="submit"]'
      );

      const originalButtonText = submitButton.innerHTML;

      const formData = new FormData(contactForm);

      const name = formData.get("name")?.trim();
      const email = formData.get("email")?.trim();
      const message = formData.get("message")?.trim();

      if (!name || !email || !message) {
        formMessage.textContent =
          "Please fill in all required fields.";

        formMessage.className = "form-message error";
        return;
      }

      submitButton.disabled = true;
      submitButton.innerHTML = "Sending...";

      formMessage.textContent = "";
      formMessage.className = "form-message";

      try {
        const response = await fetch(contactForm.action, {
          method: "POST",
          body: formData,
          headers: {
            Accept: "application/json",
          },
        });

        const result = await response.json();

        if (response.ok && result.success) {
          formMessage.textContent =
            "Your message has been sent successfully. We will contact you soon.";

          formMessage.className = "form-message success";

          submitButton.innerHTML = "Message Sent ✓";

          contactForm.reset();

          setTimeout(() => {
            submitButton.disabled = false;
            submitButton.innerHTML = originalButtonText;
          }, 3000);
        } else {
          throw new Error(
            result.message || "Something went wrong."
          );
        }
      } catch (error) {
        formMessage.textContent =
          "Message could not be sent. Please try again.";

        formMessage.className = "form-message error";

        submitButton.disabled = false;
        submitButton.innerHTML = originalButtonText;

        console.error("Web3Forms Error:", error);
      }
    });
  }

  // -----------------------------------------
  // Button Press Feedback
  // -----------------------------------------
  const buttons = document.querySelectorAll(".btn, .nav-button");

  buttons.forEach((button) => {
    button.addEventListener("mousedown", () => {
      button.style.transform = "scale(0.97)";
    });

    button.addEventListener("mouseup", () => {
      button.style.transform = "";
    });

    button.addEventListener("mouseleave", () => {
      button.style.transform = "";
    });
  });

  // -----------------------------------------
  // Page Loaded
  // -----------------------------------------
  document.body.classList.add("page-loaded");
});

// =========================================
// Custom Premium Dropdowns
// =========================================

document.addEventListener("DOMContentLoaded", () => {
  const customSelects = document.querySelectorAll("[data-select]");

  if (!customSelects.length) return;

  const closeAllSelects = (exceptSelect = null) => {
    customSelects.forEach((select) => {
      if (select !== exceptSelect) {
        select.classList.remove("is-open");

        const trigger = select.querySelector(
          ".custom-select-trigger"
        );

        if (trigger) {
          trigger.setAttribute("aria-expanded", "false");
        }
      }
    });
  };

  customSelects.forEach((select) => {
    const trigger = select.querySelector(
      ".custom-select-trigger"
    );

    const valueText = select.querySelector(
      ".custom-select-value"
    );

    const hiddenInput = select.querySelector(
      'input[type="hidden"]'
    );

    const options = select.querySelectorAll(
      ".custom-option"
    );

    if (!trigger || !valueText || !hiddenInput) return;

    // Open / close dropdown
    trigger.addEventListener("click", (event) => {
      event.stopPropagation();

      const isOpen = select.classList.contains("is-open");

      closeAllSelects(select);

      select.classList.toggle("is-open", !isOpen);

      trigger.setAttribute(
        "aria-expanded",
        String(!isOpen)
      );
    });

    // Select an option
    options.forEach((option) => {
      option.addEventListener("click", () => {
        const selectedValue = option.dataset.value || "";
        const selectedText =
          option.querySelector("span")?.textContent.trim() ||
          option.textContent.trim();

        hiddenInput.value = selectedValue;

        if (selectedValue === "") {
          valueText.textContent = selectedText;
          valueText.classList.add("is-placeholder");
        } else {
          valueText.textContent = selectedText;
          valueText.classList.remove("is-placeholder");
        }

        options.forEach((item) => {
          item.classList.remove("selected");
          item.setAttribute("aria-selected", "false");
        });

        option.classList.add("selected");
        option.setAttribute("aria-selected", "true");

        select.classList.remove("is-open");
        trigger.setAttribute("aria-expanded", "false");
      });
    });
  });

  // Outside click se dropdown close
  document.addEventListener("click", () => {
    closeAllSelects();
  });

  // Escape key se dropdown close
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
      closeAllSelects();
    }
  });
});/* =========================================
   SCROLL REVEAL OBSERVER
   ========================================= */

const revealElements = document.querySelectorAll(".reveal");

if ("IntersectionObserver" in window) {
  const revealObserver = new IntersectionObserver(
    (entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    {
      threshold: 0.12,
      rootMargin: "0px 0px -40px 0px",
    }
  );

  revealElements.forEach((element) => {
    revealObserver.observe(element);
  });
} else {
  revealElements.forEach((element) => {
    element.classList.add("is-visible");
  });
}